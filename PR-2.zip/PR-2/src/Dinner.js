import React from 'react'
import './App.css'

const Dinner = () => {
     return (
          <section>
               <h1>Dinner</h1>
               <img src={"https://th.bing.com/th/id/OIP._nuP1qPk7bVlcdb5_CsvAQHaEL?pid=ImgDet&rs=1"} />
          </section>
     )
}

export default Dinner