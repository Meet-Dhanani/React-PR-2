import React from 'react'
import "./App.css";

function Lunch() {
  return (
     <section>
     <h1>Lunch</h1>
    <img src={"https://www.nicomimacuri.com/wp-content/uploads/lunch_img003.jpg"} />
    </section>
  )
}

export default Lunch