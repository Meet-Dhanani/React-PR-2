import React from 'react'
import "./App.css";

function Breakfast() {
  return (
    <section>
     <h1>Breakfast</h1>
    <img src={"https://th.bing.com/th/id/R.1a4cdd62921ffc5fdbef169478c2c7c5?rik=locH9gfQcv0kHA&riu=http%3a%2f%2fvignette.wikia.nocookie.net%2ffood-lovers%2fimages%2f1%2f1e%2fBreakfast_food.jpg%2frevision%2flatest%3fcb%3d20130727212705&ehk=icczLpfuup6f8zfdVgRayE56qB9X258NSjgCQ44IjfI%3d&risl=&pid=ImgRaw&r=0"} />
    </section>
  )
}

export default Breakfast