import React from "react";
import Breakfast from './Breakfast';
import Lunch from './Lunch';
import Dinner from './Dinner';

class TimerClassComponent extends React.Component {
  render() {
    class Time extends React.Component {
      constructor() {
        super();
        this.state = {
          currentTime: new Date().getSeconds(),
        };
      }

      componentDidMount() {
        this.interval = setInterval(() => {
          this.setState({
            currentTime: new Date().getSeconds(),
          });
        }, 1000);
      }

      componentWillUnmount() {
        clearInterval(this.interval);
      }

      render() {
        let time;

        if (this.state.currentTime >= 1 && this.state.currentTime < 20) {
          time = <Breakfast />;
        } else if (this.state.currentTime >= 20 && this.state.currentTime < 40) {
          time = <Lunch />;
        } else if (this.state.currentTime >= 40 && this.state.currentTime < 60) {
          time = <Dinner />;
        }

        return (
          <>
            <h1> Meet Dhanani</h1>
            <hr />
            <h1>{this.state.currentTime}</h1>
            <div>{time}</div>
            <hr/>
          </>
        );
      }
    }

    return (
      <div>
        <Time />
      </div>
    );
  }
}



export default TimerClassComponent;